import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const code=ts.transpileModule(fs.readFileSync(new URL('../lib/game.ts',import.meta.url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;
const {Game,initialState,cells,validSave}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));

test('seven-bag distribution and collision boundaries',()=>{
 const g=new Game('classic');for(let i=0;i<10;i++)assert.deepEqual(Array.from({length:7},()=>g.randomPiece()).sort(),[1,2,3,4,5,6,7]);
 g.start();for(let i=0;i<20;i++)g.move(-1);assert.ok(cells(g.state.piece).every(c=>c.x>=0));
 for(let i=0;i<20;i++)g.move(1);assert.ok(cells(g.state.piece).every(c=>c.x<10));
 g.drop();assert.equal(g.state.board.flat().filter(Boolean).length,4);
});
test('four-line clear counts points and advances level',()=>{
 const g=new Game('classic');g.state.status='playing';g.state.lines=6;
 for(let y=16;y<20;y++)g.state.board[y]=Array.from({length:10},(_,x)=>x===5?0:4);
 g.state.piece={type:1,rotation:1,x:3,y:16};g.lockPiece();
 assert.equal(g.state.lines,10);assert.equal(g.state.score,800);assert.equal(g.state.level,2);assert.equal(g.state.board.flat().filter(Boolean).length,0);
});
test('paused games do not move; serialized games resume exact board and queue',()=>{
 const g=new Game('neon');g.start();g.move(1);g.rotate();g.down();g.pause();
 const before=structuredClone(g.state);g.step(100);g.move(-1);g.down();g.drop();assert.deepEqual(g.state,before);
 const saved=JSON.parse(JSON.stringify(g.state));saved.status='playing';const restored=new Game('neon',saved);
 assert.equal(restored.state.status,'paused');assert.deepEqual(restored.state,before);restored.resume();assert.equal(restored.state.status,'playing');
});
test('landing delay allows adjustment, then locks',()=>{
 const g=new Game('classic');g.start();g.state.piece=g.ghost();const n=g.state.board.flat().filter(Boolean).length;
 g.step(100);assert.equal(g.state.board.flat().filter(Boolean).length,n);for(let i=0;i<4;i++)g.step(100);
 assert.equal(g.state.board.flat().filter(Boolean).length,n+4);
});
test('top out and restart preserve best; modes stay independent',()=>{
 const a=new Game('classic'),b=new Game('neon');a.state.board[0]=Array(10).fill(1);a.state.score=1200;a.state.best=1200;a.start();assert.equal(a.state.status,'over');a.restart();assert.equal(a.state.best,1200);assert.equal(a.state.score,0);assert.equal(b.state.status,'ready');
});
test('saved payload validation rejects corrupted boards',()=>{
 const v={version:1,revision:123,activeMode:'classic',games:{classic:initialState(),neon:initialState()},settings:{music:true,effects:true,volume:.35,quietMotion:false}};
 assert.equal(validSave(v),true);v.games.classic.board[0][0]=9;assert.equal(validSave(v),false);
});
