import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';

const transpile = path => ts.transpileModule(fs.readFileSync(new URL(path, import.meta.url), 'utf8'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 },
}).outputText;
const moduleURL = code => 'data:text/javascript;base64,' + Buffer.from(code).toString('base64');
const gameURL = moduleURL(transpile('../lib/game.ts'));
const { Game, initialState } = await import(gameURL);
const persistenceURL = moduleURL(transpile('../lib/progress-client.ts').replace('"./game"', JSON.stringify(gameURL)));
const { deviceKey, loadProgress, writeProgress, readCache } = await import(persistenceURL);
const values = new Map();
globalThis.localStorage = {
  getItem: key => values.get(key) ?? null,
  setItem: (key, value) => values.set(key, value),
};
globalThis.fetch = () => { throw new Error('The static game must not need a server.'); };

test('a first-time visitor can load and both modes restore exact progress without a server', async () => {
  const key = deviceKey();
  assert.equal(await loadProgress(key), null);
  const classic = new Game('classic'); classic.start(); classic.move(-1); classic.drop();
  const neon = new Game('neon'); neon.start(); neon.rotate(); neon.move(1); neon.drop();
  const payload = { version: 1, revision: 100, activeMode: 'neon',
    games: { classic: classic.state, neon: neon.state },
    settings: { music: true, effects: false, volume: .35, quietMotion: true } };
  await writeProgress(key, payload);
  const saved = await loadProgress(key);
  assert.deepEqual(saved, payload);
  for (const mode of ['classic', 'neon']) {
    const restored = new Game(mode, saved.games[mode]);
    assert.equal(restored.state.status, 'paused');
    assert.deepEqual(restored.state.board, saved.games[mode].board);
    assert.deepEqual(restored.state.piece, saved.games[mode].piece);
    assert.deepEqual(restored.state.queue, saved.games[mode].queue);
  }
  await writeProgress(key, { ...payload, revision: 99, activeMode: 'classic' });
  assert.equal((await loadProgress(key)).activeMode, 'neon');
});

test('corrupt saves are ignored and storage failures do not report success', async () => {
  values.set('block-time-cache-v1', '{invalid');
  assert.equal(readCache(), null);
  values.set('block-time-cache-v1', JSON.stringify({ version: 1, games: {} }));
  assert.equal(readCache(), null);
  await assert.rejects(writeProgress('local', { invalid: true }), /Invalid game progress/);
  const setItem = localStorage.setItem;
  localStorage.setItem = () => { throw new Error('Storage quota exceeded'); };
  const payload = { version: 1, revision: 200, activeMode: 'classic',
    games: { classic: initialState(), neon: initialState() },
    settings: { music: true, effects: true, volume: .35, quietMotion: false } };
  try {
    assert.throws(deviceKey, /Storage quota exceeded/);
    await assert.rejects(writeProgress('local', payload), /Storage quota exceeded/);
  } finally { localStorage.setItem = setItem; }
});
