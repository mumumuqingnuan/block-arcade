import type { Mode, GameEvent } from "./game";

// A small original looping score: two arrangements, no remote media dependency.
const MELODY=[76,0,79,81,79,76,74,0,72,74,76,79,76,74,72,0,69,0,72,76,74,72,69,67,69,72,74,76,74,72,69,0,76,79,84,83,81,79,76,0,74,76,79,81,79,76,74,0,72,76,79,76,74,72,69,67,69,72,74,71,72,0,0,0];
export class ArcadeAudio {
  context:AudioContext|null=null;master:GainNode|null=null;musicBus:GainNode|null=null;sfxBus:GainNode|null=null;
  music=true;effects=true;volume=.35;mode:Mode="classic";playing=false;tick=0;nextTime=0;timer:ReturnType<typeof setInterval>|null=null;
  async unlock() {
    if(!this.context){const AC=window.AudioContext||(window as unknown as {webkitAudioContext:typeof AudioContext}).webkitAudioContext;if(!AC)return;
      this.context=new AC();this.master=this.context.createGain();this.master.connect(this.context.destination);
      this.musicBus=this.context.createGain();this.musicBus.connect(this.master);this.sfxBus=this.context.createGain();this.sfxBus.connect(this.master);this.configure();
    }
    if(this.context.state!=="running")await this.context.resume();
  }
  configure() {if(!this.context)return;const t=this.context.currentTime;this.master!.gain.setTargetAtTime(this.volume,t,.03);this.musicBus!.gain.setTargetAtTime(this.music&&this.playing?.55:0,t,.035);this.sfxBus!.gain.setTargetAtTime(this.effects?.7:0,t,.02);}
  note(midi:number,time:number,duration:number,level:number,type:OscillatorType="triangle",bus=this.musicBus) {
    if(!this.context||!bus||!midi)return;
    const o=this.context.createOscillator(),g=this.context.createGain();o.type=type;o.frequency.value=440*Math.pow(2,(midi-69)/12);
    g.gain.setValueAtTime(0,time);g.gain.linearRampToValueAtTime(level,time+.015);g.gain.exponentialRampToValueAtTime(.001,time+duration);o.connect(g);g.connect(bus);o.start(time);o.stop(time+duration+.04);o.onended=()=>{o.disconnect();g.disconnect();};
  }
  start(mode:Mode) {this.mode=mode;this.playing=true;this.configure();if(!this.context||this.timer)return;
    this.nextTime=this.context.currentTime+.08;this.timer=setInterval(()=>this.schedule(),60);this.schedule();
  }
  schedule() {if(!this.context||!this.playing)return;const step=this.mode==="classic"?.25:.2;
    if(this.nextTime<this.context.currentTime-.5)this.nextTime=this.context.currentTime+.05;
    while(this.nextTime<this.context.currentTime+.18){const i=this.tick%MELODY.length;
      if(this.music){this.note(MELODY[i],this.nextTime,step*.85,.18,this.mode==="classic"?"square":"triangle");
        if(i%4===0)this.note([48,48,45,43][Math.floor(i/16)],this.nextTime,step*3,.24,"sine");
        if(this.mode==="neon"){this.note([60,64,67,72][i%4],this.nextTime,step*.65,.1,"sawtooth");if(i%2===0)this.kick(this.nextTime);}
      }this.tick++;this.nextTime+=step;
    }
  }
  kick(time:number) {if(!this.context||!this.musicBus)return;const o=this.context.createOscillator(),g=this.context.createGain();o.frequency.setValueAtTime(110,time);o.frequency.exponentialRampToValueAtTime(36,time+.12);g.gain.setValueAtTime(.28,time);g.gain.exponentialRampToValueAtTime(.001,time+.18);o.connect(g);g.connect(this.musicBus);o.start(time);o.stop(time+.2);o.onended=()=>{o.disconnect();g.disconnect();};}
  pause(){this.playing=false;this.configure();if(this.timer)clearInterval(this.timer);this.timer=null;}
  effect(e:GameEvent) {if(!this.context||!this.effects)return;const t=this.context.currentTime;
    if(e.kind==="rotate")this.note(79,t,.08,.1,"sine",this.sfxBus);
    if(e.kind==="lock"||e.kind==="drop")this.note(48,t,.1,.2,"triangle",this.sfxBus);
    if(e.kind==="clear")[72,76,79,...(e.count===4?[84,88]:[])].forEach((n,i)=>this.note(n,t+i*.07,.22,.23,"triangle",this.sfxBus));
    if(e.kind==="over")[64,60,55,48].forEach((n,i)=>this.note(n,t+i*.16,.3,.16,"triangle",this.sfxBus));
  }
  dispose(){this.pause();void this.context?.close();}
}
