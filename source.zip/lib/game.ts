export type Mode = "classic" | "neon";
export type Status = "ready" | "playing" | "paused" | "over";
export type Piece = { type: number; rotation: number; x: number; y: number };
export type GameState = {
  board: number[][]; piece: Piece | null; queue: number[]; bag: number[];
  score: number; best: number; lines: number; level: number; status: Status;
  gravity: number; lock: number; resets: number; combo: number;
};
export type GameEvent = { kind: "move" | "rotate" | "drop" | "lock" | "clear" | "over" | "state"; rows?: number[]; count?: number; bonus?: number; cells?: {x:number;y:number;type:number}[] };
export const COLORS = ["", "#42706b", "#b18b3f", "#796384", "#46657e", "#b46d43", "#5d7850", "#aa5757"];
export const NEON_COLORS = ["", "#20b8b2", "#d8aa4e", "#a17aca", "#527fc9", "#d58956", "#42af83", "#c76683"];
export const SHAPES = [[], [[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]], [[1,1],[1,1]], [[0,1,0],[1,1,1],[0,0,0]], [[1,0,0],[1,1,1],[0,0,0]], [[0,0,1],[1,1,1],[0,0,0]], [[0,1,1],[1,1,0],[0,0,0]], [[1,1,0],[0,1,1],[0,0,0]]];
export function matrix(type:number, rotation=0):number[][] {
  let m = SHAPES[type].map(r => [...r]);
  for (let i=0;i<rotation;i++) m = m[0].map((_,x)=>m.map(r=>r[x]).reverse());
  return m;
}
export function cells(piece:Piece) {
  const result:{x:number;y:number;type:number}[]=[];
  matrix(piece.type,piece.rotation).forEach((r,y)=>r.forEach((n,x)=>{if(n)result.push({x:piece.x+x,y:piece.y+y,type:piece.type});}));
  return result;
}
export function initialState(best=0):GameState {
  return {board:Array.from({length:20},()=>Array(10).fill(0)),piece:null,queue:[],bag:[],score:0,best,lines:0,level:1,status:"ready",gravity:0,lock:0,resets:0,combo:-1};
}
export function validState(s:unknown):s is GameState {
  if(!s||typeof s!=="object") return false;
  const g=s as GameState;
  const integer=(n:unknown,min:number,max:number)=>typeof n==="number"&&Number.isInteger(n)&&n>=min&&n<=max;
  const list=(q:unknown,max:number)=>Array.isArray(q)&&q.length<=max&&q.every(n=>integer(n,1,7));
  if(!Array.isArray(g.board)||g.board.length!==20||!g.board.every(r=>Array.isArray(r)&&r.length===10&&r.every(n=>integer(n,0,7)))) return false;
  if(!list(g.queue,14)||!list(g.bag,7)||!integer(g.score,0,1e12)||!integer(g.best,0,1e12)||!integer(g.lines,0,1e8)||!integer(g.level,1,1e8))return false;
  if(!["ready","playing","paused","over"].includes(g.status)||!Number.isFinite(g.gravity)||g.gravity<0||g.gravity>2000||!Number.isFinite(g.lock)||g.lock<0||g.lock>2000||!integer(g.resets,0,15)||!integer(g.combo,-1,1e8))return false;
  if(g.piece!==null) {const p=g.piece;if(!p||!integer(p.type,1,7)||!integer(p.rotation,0,3)||!integer(p.x,-4,10)||!integer(p.y,-4,20))return false;}
  return g.status==="ready"||g.status==="over"||g.piece!==null;
}
export class Game {
  state:GameState; mode:Mode; version=0;
  onEvent:(e:GameEvent)=>void = ()=>{};
  constructor(mode:Mode,state?:GameState) {
    this.mode=mode;this.state=state?structuredClone(state):initialState();
    if(this.state.status==="playing") this.state.status="paused";
  }
  emit(e:GameEvent) {this.version++;this.onEvent(e);}
  randomPiece() {
    if(!this.state.bag.length){this.state.bag=[1,2,3,4,5,6,7];for(let i=6;i>0;i--){const j=Math.floor(Math.random()*(i+1));[this.state.bag[i],this.state.bag[j]]=[this.state.bag[j],this.state.bag[i]];}}
    return this.state.bag.pop()!;
  }
  collides(p:Piece) {return cells(p).some(c=>c.x<0||c.x>=10||c.y>=20||(c.y>=0&&this.state.board[c.y][c.x]!==0));}
  ghost() {if(!this.state.piece)return null;let p={...this.state.piece};for(let i=0;i<25&&!this.collides({...p,y:p.y+1});i++)p.y++;return p;}
  spawn() {
    while(this.state.queue.length<4)this.state.queue.push(this.randomPiece());
    const type=this.state.queue.shift()!;this.state.queue.push(this.randomPiece());
    this.state.piece={type,rotation:0,x:type===2?4:3,y:type===1?-1:0};
    this.state.gravity=0;this.state.lock=0;this.state.resets=0;
    if(this.collides(this.state.piece)){this.state.status="over";this.state.piece=null;this.emit({kind:"over"});}
  }
  start() {if(this.state.status!=="ready")return;this.state.status="playing";this.spawn();this.emit({kind:"state"});}
  restart() {const best=this.state.best;this.state=initialState(best);this.start();}
  pause() {if(this.state.status==="playing"){this.state.status="paused";this.emit({kind:"state"});}}
  resume() {if(this.state.status==="paused"){this.state.status="playing";this.emit({kind:"state"});}}
  get speed() {return Math.max(this.mode==="classic"?95:75,(this.mode==="classic"?1100:900)*Math.pow(.83,this.state.level-1));}
  adjustGround(oldGrounded:boolean) {if(oldGrounded&&this.state.resets<15){this.state.lock=0;this.state.resets++;}}
  move(dx:number) {
    const s=this.state;if(s.status!=="playing"||!s.piece)return false;
    const grounded=this.collides({...s.piece,y:s.piece.y+1});const p={...s.piece,x:s.piece.x+dx};
    if(this.collides(p))return false;s.piece=p;this.adjustGround(grounded);this.emit({kind:"move"});return true;
  }
  rotate() {
    const s=this.state;if(s.status!=="playing"||!s.piece)return false;
    const grounded=this.collides({...s.piece,y:s.piece.y+1});
    for(const [dx,dy] of [[0,0],[-1,0],[1,0],[-2,0],[2,0],[0,-1],[-1,-1],[1,-1],[0,-2]]){
      const p={...s.piece,rotation:(s.piece.rotation+1)%4,x:s.piece.x+dx,y:s.piece.y+dy};
      if(!this.collides(p)){s.piece=p;this.adjustGround(grounded);this.emit({kind:"rotate"});return true;}
    }return false;
  }
  down(manual=false) {
    const s=this.state;if(s.status!=="playing"||!s.piece)return false;
    const p={...s.piece,y:s.piece.y+1};if(this.collides(p))return false;
    s.piece=p;s.lock=0;if(manual){s.score++;s.best=Math.max(s.best,s.score);}this.emit({kind:"move"});return true;
  }
  drop() {
    const s=this.state;if(s.status!=="playing"||!s.piece)return;
    const dest=this.ghost()!;const before=cells(s.piece);s.score+=(dest.y-s.piece.y)*2;s.piece=dest;
    this.emit({kind:"drop",cells:before});this.lockPiece();
  }
  lockPiece() {
    const s=this.state;if(!s.piece)return;
    const landed=cells(s.piece);
    if(landed.some(c=>c.y<0)){s.status="over";s.piece=null;s.best=Math.max(s.best,s.score);this.emit({kind:"over"});return;}
    for(const c of landed)s.board[c.y][c.x]=c.type;
    const rows:number[]=[];s.board.forEach((r,y)=>{if(r.every(Boolean))rows.push(y);});
    if(rows.length){
      const cleared=rows.flatMap(y=>s.board[y].map((type,x)=>({x,y,type})));
      s.board=s.board.filter((_,y)=>!rows.includes(y));while(s.board.length<20)s.board.unshift(Array(10).fill(0));
      s.combo++;const bonus=([0,100,300,500,800][rows.length]+Math.max(0,s.combo)*50)*s.level;
      s.score+=bonus;s.lines+=rows.length;s.level=Math.floor(s.lines/10)+1;
      this.emit({kind:"clear",rows,count:rows.length,bonus,cells:cleared});
    }else{s.combo=-1;this.emit({kind:"lock",cells:landed});}
    s.best=Math.max(s.best,s.score);this.spawn();this.emit({kind:"state"});
  }
  step(ms:number) {
    const s=this.state;if(s.status!=="playing"||!s.piece)return;
    const dt=Math.max(0,Math.min(ms,100));s.gravity+=dt;
    if(s.gravity>=this.speed){s.gravity-=this.speed;this.down();}
    if(s.piece&&this.collides({...s.piece,y:s.piece.y+1})){s.lock+=dt;if(s.lock>=500)this.lockPiece();}else{s.lock=0;}
  }
}
export type SaveData = {version:1;revision:number;activeMode:Mode;games:Record<Mode,GameState>;settings:{music:boolean;effects:boolean;volume:number;quietMotion:boolean}};
export function validSave(v:unknown):v is SaveData {
  if(!v||typeof v!=="object")return false;const s=v as SaveData;
  return s.version===1&&Number.isSafeInteger(s.revision)&&s.revision>=0&&["classic","neon"].includes(s.activeMode)&&!!s.games&&validState(s.games.classic)&&validState(s.games.neon)&&!!s.settings&&typeof s.settings.music==="boolean"&&typeof s.settings.effects==="boolean"&&typeof s.settings.quietMotion==="boolean"&&Number.isFinite(s.settings.volume)&&s.settings.volume>=0&&s.settings.volume<=1;
}
