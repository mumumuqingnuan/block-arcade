import { validSave, type SaveData } from "./game";

const KEY = "block-time-device-v1";
const CACHE = "block-time-cache-v1";

export function deviceKey() {
  // Verify that this browser permits persistent storage before promising saves.
  const key = localStorage.getItem(KEY) || "local";
  localStorage.setItem(KEY, key);
  return key;
}

export function readCache(): SaveData | null {
  try {
    const saved = JSON.parse(localStorage.getItem(CACHE) ?? "null");
    return validSave(saved) ? saved : null;
  } catch {
    return null;
  }
}

function persist(save: SaveData) {
  if (!validSave(save)) throw new Error("Invalid game progress");
  const current = readCache();
  if (!current || current.revision <= save.revision) {
    localStorage.setItem(CACHE, JSON.stringify(save));
  }
}

export function cacheSave(save: SaveData) {
  try { persist(save); } catch { /* writeProgress reports the storage failure. */ }
}

export async function loadProgress(_key: string): Promise<SaveData | null> {
  return readCache();
}

export async function writeProgress(_key: string, save: SaveData, _keepalive = false) {
  persist(save);
  return { saved: true };
}
