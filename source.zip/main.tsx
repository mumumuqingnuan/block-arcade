import { createRoot } from "react-dom/client";
import Arcade from "./components/game/arcade";
import "./app/globals.css";

createRoot(document.getElementById("root")!).render(<Arcade />);
