"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, AudioLines, Check, ChevronDown, ChevronUp, CloudCheck, CloudOff, Gamepad2, Keyboard, LoaderCircle, Maximize, Minimize, Music2, Pause, Play, RotateCcw, RotateCw, ShieldCheck, Sparkles, Trophy, Volume2, X } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Game, initialState, matrix, COLORS, NEON_COLORS, type GameEvent, type GameState, type Mode, type SaveData } from "@/lib/game";
import { ArcadeAudio } from "@/lib/music";
import { deviceKey, readCache, cacheSave, loadProgress, writeProgress } from "@/lib/progress-client";
import Board from "./board";
import InstallGuide from "./install-guide";

type Settings=SaveData["settings"];
const DEFAULT_SETTINGS:Settings={music:true,effects:true,volume:.35,quietMotion:false};
type Action="left"|"right"|"rotate"|"down"|"drop";
type Session={games:Record<Mode,Game>;key:string;mode:Mode;settings:Settings;revision:number;dirty:boolean;saving:boolean};
function MiniPiece({type,mode,small=false}:{type:number;mode:Mode;small?:boolean}) {
  if(!type)return <span className="next-empty">—</span>;
  const m=matrix(type).filter(r=>r.some(Boolean));const left=Math.min(...m.flatMap(r=>r.map((n,x)=>n?x:9)).filter(x=>x<9));const right=Math.max(...m.flatMap(r=>r.map((n,x)=>n?x:-1)));
  return <div className={`mini-piece ${small?"small":""}`} style={{gridTemplateColumns:`repeat(${right-left+1},1fr)`,"--piece-color":(mode==="classic"?COLORS:NEON_COLORS)[type]} as React.CSSProperties} aria-label={["","长条形","正方形","T形","J形","L形","S形","Z形"][type]}>{m.flatMap((r,y)=>r.slice(left,right+1).map((n,x)=><i key={`${x}-${y}`} className={n?"filled":""}/>))}</div>;
}
function BlockMark(){return <span className="block-mark" aria-hidden="true"><i/><i/><i/><i/></span>;}
function TouchButton({action,label,children,onAction,disabled,repeat=false}:{action:Action;label:string;children:React.ReactNode;onAction:(a:Action)=>void;disabled:boolean;repeat?:boolean}){
  const timer=useRef<ReturnType<typeof setTimeout>|null>(null),interval=useRef<ReturnType<typeof setInterval>|null>(null),held=useRef(false);
  const stop=()=>{held.current=false;if(timer.current)clearTimeout(timer.current);if(interval.current)clearInterval(interval.current);timer.current=null;interval.current=null;};
  useEffect(()=>{if(disabled)stop();return stop;},[disabled]);
  return <button className={`touch-key touch-${action}`} disabled={disabled} aria-label={label} onPointerDown={e=>{if(e.button!==0)return;e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);held.current=true;onAction(action);if(repeat)timer.current=setTimeout(()=>{interval.current=setInterval(()=>onAction(action),action==="down"?55:85);},220);}} onPointerUp={stop} onPointerCancel={stop} onLostPointerCapture={stop} onContextMenu={e=>e.preventDefault()} onClick={e=>{if(e.detail===0)onAction(action);}}>{children}<span>{label}</span></button>;
}
export default function Arcade(){
  const [mode,setMode]=useState<Mode>("classic"),[state,setState]=useState<GameState>(initialState),[settings,setSettings]=useState(DEFAULT_SETTINGS);
  const [loaded,setLoaded]=useState(false),[loadError,setLoadError]=useState(""),[attempt,setAttempt]=useState(0),[saveStatus,setSaveStatus]=useState<"loading"|"saved"|"saving"|"offline">("loading");
  const [boardReady,setBoardReady]=useState(false),[boardError,setBoardError]=useState(""),[restartOpen,setRestartOpen]=useState(false),[full,setFull]=useState(false),[largeView,setLargeView]=useState(false),[restored,setRestored]=useState(false),[settingsOpen,setSettingsOpen]=useState(false),[notice,setNotice]=useState("");
  const [celebration,setCelebration]=useState<{label:string;bonus:number;id:number}|null>(null);
  const [installOpen,setInstallOpen]=useState(false);
  const session=useRef<Session|null>(null),audio=useRef<ArcadeAudio|null>(null),effect=useRef<((e:GameEvent)=>void)|null>(null),celebrationTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const root=useRef<HTMLDivElement>(null),playArea=useRef<HTMLDivElement>(null),modal=useRef(false);modal.current=restartOpen||installOpen;
  const snapshot=useCallback(():SaveData|null=>{const s=session.current;if(!s)return null;return {version:1,revision:s.revision,activeMode:s.mode,games:{classic:structuredClone(s.games.classic.state),neon:structuredClone(s.games.neon.state)},settings:{...s.settings}};},[]);
  const flush=useCallback(async(keepalive=false)=>{
    const s=session.current;if(!s||!s.dirty||(!keepalive&&s.saving))return;
    const data=snapshot();if(!data)return;cacheSave(data);if(!keepalive){s.saving=true;setSaveStatus("saving");}
    try{await writeProgress(s.key,data,keepalive);if(s.revision===data.revision){s.dirty=false;setSaveStatus("saved");}}
    catch{setSaveStatus("offline");}
    finally{if(!keepalive)s.saving=false;}
  },[snapshot]);
  const dirty=useCallback(()=>{const s=session.current;if(!s)return;s.revision=Math.max(Date.now(),s.revision+1);s.dirty=true;const data=snapshot();if(data)cacheSave(data);},[snapshot]);
  const refresh=useCallback(()=>{const s=session.current;if(s)setState({...s.games[s.mode].state});},[]);
  const syncAudio=useCallback(()=>{const s=session.current,a=audio.current;if(!s||!a)return;Object.assign(a,s.settings);a.configure();if(s.games[s.mode].state.status==="playing")a.start(s.mode);else a.pause();},[]);
  const audioUnlock=useCallback(()=>{void audio.current?.unlock().then(()=>{syncAudio();setNotice("");}).catch(()=>{setNotice("声音未能开启，点一下音乐开关重试。");});},[syncAudio]);
  const pause=useCallback(()=>{const s=session.current;if(!s)return;s.games[s.mode].pause();audio.current?.pause();refresh();void flush();},[flush,refresh]);
  const act=useCallback((action:Action)=>{const s=session.current;if(!s||modal.current)return;const g=s.games[s.mode];if(g.state.status!=="playing")return;
    if(action==="left")g.move(-1);if(action==="right")g.move(1);if(action==="rotate")g.rotate();if(action==="down")g.down(true);if(action==="drop")g.drop();
  },[]);
  const playPause=useCallback(()=>{setRestored(false);const s=session.current;if(!s||modal.current)return;const g=s.games[s.mode];audioUnlock();if(g.state.status==="playing")pause();else if(g.state.status==="paused"){g.resume();syncAudio();}else if(g.state.status==="ready"){g.start();syncAudio();}else{g.restart();syncAudio();}if(g.state.status==="playing")playArea.current?.focus({preventScroll:true});refresh();void flush();},[audioUnlock,pause,syncAudio,refresh,flush]);
  useEffect(()=>{
    let disposed=false;setLoaded(false);setLoadError("");audio.current=new ArcadeAudio();let last=performance.now(),frame=0;
    const boot=async()=>{
      let key:string;try{key=deviceKey();}catch{setLoadError("请允许浏览器保存网站数据，然后重试。这样下次才能找到这一局。");return;}
      const cache=readCache();let saved:SaveData|null=null,offline=false;
      try{saved=await loadProgress(key);}catch{if(!cache){if(!disposed)setLoadError("暂时无法读取本机进度，请允许保存网站数据后重试。");return;}offline=true;}
      if(disposed)return;
      if(cache&&(!saved||cache.revision>saved.revision))saved=cache;
      const mode=saved?.activeMode??"classic";const opts=saved?.settings??{...DEFAULT_SETTINGS,quietMotion:window.matchMedia("(prefers-reduced-motion: reduce)").matches};
      const games={classic:new Game("classic",saved?.games.classic),neon:new Game("neon",saved?.games.neon)};
      session.current={games,key,mode,settings:opts,revision:saved?.revision??Date.now(),dirty:!!saved,saving:false};
      for(const [name,g] of Object.entries(games)){g.onEvent=(e:GameEvent)=>{
        if(disposed)return;dirty();
        if(session.current?.mode===name){refresh();effect.current?.(e);audio.current?.effect(e);
          if(e.kind==="clear"){setCelebration({label:e.count===4?"四行全消！":e.count===3?"漂亮！三行消除":e.count===2?"双行消除":"消除一行",bonus:e.bonus??0,id:Date.now()});if(celebrationTimer.current)clearTimeout(celebrationTimer.current);celebrationTimer.current=setTimeout(()=>setCelebration(null),1600);}
          if(e.kind==="over"){audio.current?.pause();void flush();}
        }
      };}
      setRestored(games[mode].state.status==="paused");setMode(mode);setSettings({...opts});setState({...games[mode].state});setLoaded(true);setSaveStatus(offline?"offline":"saved");syncAudio();
      if(saved)void flush();
    };void boot();
    const loop=(now:number)=>{if(!document.hidden){const s=session.current;s?.games[s.mode].step(now-last);}last=now;frame=requestAnimationFrame(loop);};frame=requestAnimationFrame(loop);
    const timer=setInterval(()=>void flush(),1200);
    const hidden=()=>{if(document.hidden){pause();void flush(true);}};
    const leave=()=>{pause();void flush(true);};const online=()=>void flush();
    const keydown=(e:KeyboardEvent)=>{if(e.defaultPrevented||modal.current)return;const target=e.target as HTMLElement;if(target.closest('input,textarea,select,[role="slider"],[role="tab"],[role="switch"],[contenteditable="true"]'))return;
      if((e.code==="KeyP"||e.code==="Escape")&&!e.repeat){e.preventDefault();const g=session.current?.games[session.current.mode];if(g?.state.status==="playing")pause();else if(g?.state.status==="paused")playPause();return;}
      if(e.code==="Enter"&&!e.repeat&&!target.closest("button")){e.preventDefault();playPause();return;}
      const mapped:Record<string,Action>={ArrowLeft:"left",ArrowRight:"right",ArrowUp:"rotate",ArrowDown:"down",Space:"drop"};const action=mapped[e.code];
      if(action&&session.current?.games[session.current.mode].state.status==="playing"){if(e.code==="Space"&&target.closest("button"))return;e.preventDefault();if((action==="rotate"||action==="drop")&&e.repeat)return;act(action);}
    };
    document.addEventListener("visibilitychange",hidden);window.addEventListener("pagehide",leave);window.addEventListener("blur",leave);window.addEventListener("online",online);window.addEventListener("keydown",keydown);
    const fs=()=>{setFull(!!document.fullscreenElement);if(!document.fullscreenElement)setLargeView(false);};document.addEventListener("fullscreenchange",fs);
    return ()=>{disposed=true;cancelAnimationFrame(frame);clearInterval(timer);document.removeEventListener("visibilitychange",hidden);window.removeEventListener("pagehide",leave);window.removeEventListener("blur",leave);window.removeEventListener("online",online);window.removeEventListener("keydown",keydown);document.removeEventListener("fullscreenchange",fs);if(celebrationTimer.current)clearTimeout(celebrationTimer.current);audio.current?.dispose();};
  },[attempt,act,dirty,flush,pause,playPause,refresh,syncAudio]);
  const changeMode=(value:string)=>{const next=value as Mode;const s=session.current;if(!s||next===s.mode)return;pause();s.mode=next;setRestored(s.games[next].state.status==="paused");setMode(next);setBoardReady(false);setBoardError("");setCelebration(null);dirty();refresh();syncAudio();void flush();};
  const updateSettings=(patch:Partial<Settings>)=>{const s=session.current;if(!s)return;if(patch.quietMotion!==undefined)pause();s.settings={...s.settings,...patch};setSettings({...s.settings});dirty();audioUnlock();syncAudio();void flush();};
  const requestRestart=()=>{pause();setRestartOpen(true);};
  const restart=()=>{setRestored(false);const s=session.current;if(!s)return;modal.current=false;setRestartOpen(false);audioUnlock();s.games[s.mode].restart();syncAudio();playArea.current?.focus({preventScroll:true});void flush();};
  const toggleFull=async()=>{pause();const next=!largeView;setLargeView(next);try{if(!next&&document.fullscreenElement)await document.exitFullscreen();else if(next&&root.current?.requestFullscreen)await root.current.requestFullscreen();}catch{/* The enlarged page layout also works without native fullscreen. */}requestAnimationFrame(()=>root.current?.scrollIntoView({block:"start"}));};
  const error=useCallback((m:string)=>{setBoardError(m);setBoardReady(false);pause();},[pause]);
  const ready=useCallback(()=>{setBoardReady(true);setBoardError("");},[]);
  const activeGame=session.current?.games[mode]??null;
  const isPlaying=state.status==="playing",progress=state.lines%10,canPlay=loaded&&boardReady&&!boardError;
  const saveLabel=saveStatus==="saved"?"进度已保存在本机":saveStatus==="saving"?"正在保存进度":saveStatus==="offline"?"本机保存失败":"正在读取进度";
  const statusLabel=isPlaying?"游戏中":state.status==="paused"?"已暂停":state.status==="over"?"本局结束":"准备开始";
  return <div ref={root} className={`arcade theme-${mode} ${largeView?"large-view":""} ${settings.quietMotion?"quiet-motion":""}`}>
    <div className="ambient-orb orb-one"/><div className="ambient-orb orb-two"/>
    <header className="site-header"><a href="./" className="brand" aria-label="方块时光首页"><BlockMark/><div><strong>方块时光<span>BLOCK TIME</span></strong><p>俄罗斯方块</p></div></a><div className="header-actions"><span className="desktop-save"><CloudCheck size={16}/> 自动存档</span><InstallGuide open={installOpen} onOpenChange={open=>{if(open)pause();setInstallOpen(open);}}/>{largeView&&<button className="icon-button large-pause" onClick={playPause} disabled={!canPlay}>{isPlaying?<Pause size={20}/>:<Play size={20}/>}<span>{isPlaying?"暂停并保存":state.status==="ready"?"开始游戏":state.status==="over"?"再玩一局":"继续游戏"}</span></button>}<button className="icon-button enlarge-button" onClick={toggleFull} aria-pressed={largeView} aria-label={largeView?"返回普通显示":"大屏显示"} title={full?"退出全屏":"放大棋盘"}>{largeView?<Minimize size={23}/>:<Maximize size={23}/>}<span>{largeView?"返回普通显示":"大屏显示"}</span></button></div></header>
    <main className="game-layout">
      <aside className="left-panel">
        <section className="mode-section"><div className="eyebrow">选择玩法 <span>01 / 02</span></div>
          <Tabs value={mode} onValueChange={changeMode} className="mode-tabs"><TabsList aria-label="游戏模式" className="mode-list"><TabsTrigger value="classic" disabled={!loaded} className="mode-card"><span className="mode-icon"><Gamepad2/></span><span className="mode-copy"><strong>传统经典</strong><span>哑光方块 · 复古旋律</span></span><Check className="mode-check"/></TabsTrigger><TabsTrigger value="neon" disabled={!loaded} className="mode-card"><span className="mode-icon"><Sparkles/></span><span className="mode-copy"><strong>霓虹光影</strong><span>发光方块 · 落底光轨</span></span><Check className="mode-check"/></TabsTrigger></TabsList></Tabs>
          <p className="mode-footnote">两种玩法，分别自动保存。</p>
        </section>
        <section className={`sound-panel ${settingsOpen?"expanded":""}`}><button className="sound-heading" onClick={()=>setSettingsOpen(!settingsOpen)} aria-expanded={settingsOpen}><span><AudioLines size={18}/> 声音与动效</span>{settingsOpen?<ChevronUp size={18}/>:<ChevronDown size={18}/>}</button><div className="sound-content">
          <div className="setting-row"><label htmlFor="music"><Music2 size={17}/> 背景音乐</label><Switch id="music" checked={settings.music} onCheckedChange={music=>updateSettings({music})} disabled={!loaded}/></div>
          <div className="track-name"><span className={isPlaying&&settings.music?"equalizer active":"equalizer"}><i/><i/><i/><i/></span>{mode==="classic"?"复古街机 · 轻快旋律":"霓虹漫游 · 电子节奏"}</div>
          <div className="volume-row"><Volume2 size={16}/><Slider aria-label="音量" value={[Math.round(settings.volume*100)]} min={0} max={100} step={5} onValueChange={v=>updateSettings({volume:v[0]/100})} disabled={!loaded}/><span>{Math.round(settings.volume*100)}%</span></div>
          <div className="setting-row"><label htmlFor="effects">游戏音效</label><Switch id="effects" checked={settings.effects} onCheckedChange={effects=>updateSettings({effects})} disabled={!loaded}/></div>
          <div className="setting-row"><label htmlFor="motion">减少动效</label><Switch id="motion" checked={settings.quietMotion} onCheckedChange={quietMotion=>updateSettings({quietMotion})} disabled={!loaded}/></div>
          <p className="sound-tip">点“开始游戏”后，音乐一起响起。</p>
        </div></section>
        <section className="keyboard-panel"><h2><Keyboard size={18}/> 键盘操作</h2><div><span>左右移动</span><span><kbd>←</kbd> <kbd>→</kbd></span></div><div><span>旋转方块</span><kbd>↑</kbd></div><div><span>加速下落</span><kbd>↓</kbd></div><div><span>直接落底</span><kbd className="wide-key">空格</kbd></div><div><span>暂停 / 继续</span><kbd>P</kbd></div></section>
        <div className="save-note"><ShieldCheck size={20}/><p>关闭网页后，也能接着玩。<span>同一设备、同一浏览器再次打开，点“继续游戏”。</span></p></div>
      </aside>
      <section className="play-section" aria-label="游戏区域"><div className="board-heading"><h1>{mode==="classic"?"传统经典":"霓虹光影"}</h1><span className={`play-status ${isPlaying?"live":""}`}><i/>{statusLabel}</span></div>
        <div className="board-shell"><div className="board-inner" ref={playArea} tabIndex={0} role="group" aria-label="方块棋盘。方向键移动旋转，空格落底，P暂停。"><Board game={activeGame} mode={mode} quietMotion={settings.quietMotion} onReady={ready} onError={error} effectRef={effect}/>
          {celebration&&<div key={celebration.id} className="celebration" aria-live="polite"><strong>+{celebration.bonus}</strong><span>{celebration.label}</span></div>}
          {(!isPlaying||!canPlay)&&<div className={`board-overlay ${state.status==="ready"?"welcome":""}`}>
            {loadError||boardError?<><span className="overlay-icon"><CloudOff/></span><h2>稍等一下</h2><p>{loadError||boardError}</p><button className="primary-button" onClick={()=>boardError?window.location.reload():setAttempt(a=>a+1)}><RotateCw size={18}/> 重试</button></>:!loaded||!boardReady?<><LoaderCircle className="loading-spinner"/><h2>准备棋盘中</h2><p>正在找回你的游戏进度</p></>:state.status==="ready"?<><span className="intro-tetromino" aria-hidden="true"><i/><i/><i/><i/></span><span className="overlay-kicker">{mode==="classic"?"LET’S PLAY":"NEON · 光影模式"}</span><h2>{mode==="classic"?"来，玩一局。":"让方块亮起来。"}</h2><p>{mode==="classic"?"转一转，排整齐。":"落底有光轨，消行有星光。"}<br/>{mode==="classic"?"填满一行，就能消除。":"跟着音乐，慢慢玩。"}</p><button className="primary-button" onClick={playPause}><Play size={19} fill="currentColor"/> 开始游戏</button><span className="overlay-hint">从第 1 级慢慢开始</span></>:state.status==="paused"?<><span className="overlay-icon"><Pause/></span><h2>{restored?"继续上次的游戏":"游戏已暂停"}</h2><p>{restored?"上次的棋盘和分数都在。":"这一局会自动保存。"}<br/>点“继续游戏”，接着玩。</p><button className="primary-button" onClick={playPause}><Play size={19} fill="currentColor"/> 继续游戏</button><span className="overlay-hint">当前 {state.score.toLocaleString()} 分 · 第 {state.level} 级</span></>:<><span className="overlay-icon"><Trophy/></span><span className="overlay-kicker">NICE GAME</span><h2>这一局，辛苦了！</h2><strong className="final-score">{state.score.toLocaleString()}<small>分</small></strong><p>共消除 {state.lines} 行</p><button className="primary-button" onClick={playPause}><RotateCcw size={18}/> 再玩一局</button></>}
          </div>}
        </div><span className="corner-detail corner-tl"/><span className="corner-detail corner-br"/></div>
        <div className="board-under"><span><span className="ghost-key"/> 虚影提示落点</span><span>10 × 20</span></div>
        <div className="touch-controls" aria-label="触屏操作"><TouchButton action="left" label="左移" onAction={act} disabled={!isPlaying} repeat><ArrowLeft/></TouchButton><TouchButton action="rotate" label="旋转" onAction={act} disabled={!isPlaying}><RotateCw/></TouchButton><TouchButton action="right" label="右移" onAction={act} disabled={!isPlaying} repeat><ArrowRight/></TouchButton><TouchButton action="down" label="下落" onAction={act} disabled={!isPlaying} repeat><ArrowDown/></TouchButton><TouchButton action="drop" label="落到底" onAction={act} disabled={!isPlaying}><span className="hard-drop-icon"><ArrowDown/><i/></span></TouchButton></div>
      </section>
      <aside className="right-panel">
        <section className="score-panel"><span className="eyebrow">当前得分 <span>SCORE</span></span><strong className="score-number">{state.score.toLocaleString()}</strong><div className="best-score"><span><Trophy size={15}/> 最高分</span><strong>{state.best.toLocaleString()}</strong></div></section>
        <section className="level-panel"><div className="stat-pair"><div><span>等级</span><strong><small>LV.</small>{String(state.level).padStart(2,"0")}</strong></div><div><span>消除行数</span><strong>{String(state.lines).padStart(2,"0")}</strong></div></div><Progress value={progress*10} aria-label="升级进度" className="level-progress"/><p>再消除 <strong>{10-progress}</strong> 行升至下一级</p></section>
        <section className="next-panel"><h2>下一个 <span>NEXT</span></h2><div className="next-primary"><MiniPiece type={state.queue[0]??0} mode={mode}/></div><div className="next-later"><MiniPiece type={state.queue[1]??0} mode={mode} small/><span/><MiniPiece type={state.queue[2]??0} mode={mode} small/></div></section>
        <div className="game-actions"><button className={`primary-button ${isPlaying?"pause-button":""}`} onClick={playPause} disabled={!canPlay}>{isPlaying?<Pause size={20}/>:state.status==="over"?<RotateCcw size={18}/>:<Play size={18} fill="currentColor"/>}{isPlaying?"暂停并保存":state.status==="paused"?"继续游戏":state.status==="over"?"再玩一局":"开始游戏"}<kbd>P</kbd></button><button className="secondary-button" onClick={requestRestart} disabled={!loaded||state.status==="ready"}><RotateCcw size={17}/> 重新开局</button></div>
        <button className={`save-status ${saveStatus==="offline"?"offline":""}`} onClick={()=>void flush()} disabled={!loaded||saveStatus!=="offline"} aria-live="polite">{saveStatus==="offline"?<CloudOff size={16}/>:saveStatus==="saving"||saveStatus==="loading"?<LoaderCircle size={16} className="loading-spinner"/>:<CloudCheck size={16}/>}<span>{saveLabel}{saveStatus==="offline"&&<small>请允许保存网站数据 · 点此重试</small>}</span></button>
        <div className="mode-signature"><span>{mode==="classic"?"CLASSIC":"NEON"}</span><strong>{mode==="classic"?"老朋友，新纪录。":"让每次消除，都闪闪发光。"}</strong></div>
      </aside>
    </main>
    <footer className="site-footer"><span>一局一局，都是好时光。</span><span>自动保存 · 随时继续</span></footer>
    {notice&&<div className="notice" role="status"><span>{notice}</span><button onClick={()=>setNotice("")} aria-label="关闭提示"><X size={18}/></button></div>}
    <AlertDialog open={restartOpen} onOpenChange={setRestartOpen}><AlertDialogContent className="restart-dialog"><AlertDialogHeader><AlertDialogTitle>重新开始这一局？</AlertDialogTitle><AlertDialogDescription>当前{mode==="classic"?"传统经典":"霓虹光影"}的棋盘和得分会清空，最高分会保留。另一种玩法的进度不受影响。</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>保留这一局</AlertDialogCancel><AlertDialogAction onClick={restart}>重新开局</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
  </div>;
}
