import { useEffect, useState } from "react";
import { Dialog, Tabs } from "radix-ui";
import { Download, X } from "lucide-react";

type Device = "android" | "ios" | "windows" | "mac";
type InstallPrompt = Event & {
  prompt: () => Promise<unknown>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const guides: Record<Device, { label: string; title: string; steps: string[]; tip: string; help: string }> = {
  android: {
    label: "安卓",
    title: "安卓手机 / 平板 · Chrome",
    steps: [
      "用 Chrome 浏览器打开这个游戏。",
      "点右上角 ⋮，选择「安装并创建快捷方式」→「安装」。部分版本叫「添加到主屏幕」或「安装应用」。",
      "确认名称为「方块时光」，再点「安装」或「添加」。以后点主屏幕上的方块图标就能玩。",
    ],
    tip: "如果图标只出现在应用列表中，长按「方块时光」，把它拖到主屏幕。",
    help: "https://support.google.com/chrome/answer/9658361?co=GENIE.Platform%3DAndroid&hl=zh-Hans",
  },
  ios: {
    label: "iPhone / iPad",
    title: "iPhone / iPad · Safari",
    steps: [
      "用 Safari 浏览器打开这个游戏。",
      "点「分享 / 共享」（方框向上箭头），向下找到「添加到主屏幕」。部分布局先点「更多」。",
      "保留「方块时光」这个名称；如果有「作为网页 App 打开」，将它打开，再点「添加」。",
    ],
    tip: "没有看到「添加到主屏幕」？在分享列表底部点「编辑操作」，把这一项加回来。",
    help: "https://support.apple.com/zh-cn/guide/iphone/iphea86e5236/ios",
  },
  windows: {
    label: "Windows",
    title: "Windows 电脑 · Edge / Chrome",
    steps: [
      "用 Edge 或 Chrome 浏览器打开这个游戏。",
      "Edge：点右上角 … →「更多工具」→「应用」→「将此站点安装为应用」。Chrome：点 ⋮ →「投放、保存和分享」→「将网页安装为应用」。",
      "安装后添加桌面快捷方式。Edge 在 edge://apps 中找到「方块时光」→「详细信息」→「创建桌面快捷方式」；Chrome 在 chrome://apps 中右键图标 →「创建快捷方式」。",
    ],
    tip: "地址栏右侧若已有安装图标，也可以直接点击它。浏览器版本不同，菜单名称会略有差异。",
    help: "https://support.microsoft.com/en-us/edge/install-manage-or-uninstall-apps-in-microsoft-edge",
  },
  mac: {
    label: "Mac",
    title: "Mac 电脑 · Safari / Chrome",
    steps: [
      "用 Safari 打开游戏，点工具栏的分享按钮 →「添加到程序坞」。",
      "保留「方块时光」这个名称，再点「添加」。以后从程序坞里的方块图标打开。",
      "也可以用 Chrome：⋮ →「投放、保存和分享」→「将网页安装为应用」。如需桌面快捷方式，在 chrome://apps 中右键「方块时光」→「创建快捷方式」。",
    ],
    tip: "Safari 的「添加到程序坞」需要 macOS Sonoma 14 或更新版本。较旧的系统可以使用 Chrome。",
    help: "https://support.apple.com/guide/safari/add-to-dock-ibrw9e991864/mac",
  },
};

export default function InstallGuide({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [device, setDevice] = useState<Device>("windows");
  const [deferred, setDeferred] = useState<InstallPrompt | null>(null);
  const [busy, setBusy] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [standalone, setStandalone] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const ua = navigator.userAgent;
    const isAppleMobile = /iPhone|iPad|iPod/i.test(ua) || (/Macintosh/i.test(ua) && navigator.maxTouchPoints > 1);
    setDevice(isAppleMobile ? "ios" : /Android/i.test(ua) ? "android" : /Macintosh/i.test(ua) ? "mac" : "windows");
    const display = window.matchMedia("(display-mode: standalone)");
    const updateDisplay = () => setStandalone(display.matches || (navigator as Navigator & { standalone?: boolean }).standalone === true);
    updateDisplay();
    const available = (event: Event) => {
      if (typeof (event as InstallPrompt).prompt !== "function") return;
      event.preventDefault();
      setDeferred(event as InstallPrompt);
      setMessage("");
    };
    const complete = () => { setDeferred(null); setInstalled(true); };
    window.addEventListener("beforeinstallprompt", available);
    window.addEventListener("appinstalled", complete);
    display.addEventListener("change", updateDisplay);
    return () => {
      window.removeEventListener("beforeinstallprompt", available);
      window.removeEventListener("appinstalled", complete);
      display.removeEventListener("change", updateDisplay);
    };
  }, []);

  const install = async () => {
    if (!deferred || busy) return;
    const prompt = deferred;
    setDeferred(null); // Each browser install event can only be used once.
    setBusy(true);
    setMessage("");
    try {
      await prompt.prompt();
      const choice = await prompt.userChoice;
      setMessage(choice.outcome === "accepted"
        ? "已确认安装，请按浏览器提示完成。找不到图标时，可查看下面的添加方法。"
        : "已取消安装。想添加时，仍可按照下面的方法操作。");
    } catch {
      setMessage("这次没有打开安装窗口，请按下面的方法从浏览器菜单添加。");
    } finally {
      setBusy(false);
    }
  };

  return <Dialog.Root open={open} onOpenChange={onOpenChange}>
    <Dialog.Trigger asChild>
      <button className="icon-button install-entry" aria-label="添加到桌面"><Download size={20} /><span>添加到桌面</span></button>
    </Dialog.Trigger>
    <Dialog.Portal>
      <Dialog.Overlay className="install-backdrop" />
      <Dialog.Content className="install-dialog">
        <div className="install-heading">
          <img src="./icon-192.png" width="60" height="60" alt="" />
          <div><Dialog.Title>把方块时光放到桌面</Dialog.Title><Dialog.Description>添加一次，以后点图标就能玩。</Dialog.Description></div>
          <Dialog.Close className="install-close" aria-label="关闭添加说明"><X size={23} /></Dialog.Close>
        </div>
        {(standalone || installed) && <p className="install-status" role="status">{standalone ? "你正在使用独立的游戏窗口。" : "浏览器已完成安装。找不到图标时，可查看下面的添加方法。"}</p>}
        {!standalone && !installed && (deferred || busy) && <button className="install-native" onClick={() => void install()} disabled={busy}><Download size={21} />{busy ? "请在浏览器中确认" : "在这台设备上安装"}</button>}
        {!installed && message && <p className="install-status" role="status">{message}</p>}
        <Tabs.Root value={device} onValueChange={value => setDevice(value as Device)}>
          <Tabs.List className="install-devices" aria-label="选择设备">
            {(Object.keys(guides) as Device[]).map(key => <Tabs.Trigger key={key} value={key}>{guides[key].label}</Tabs.Trigger>)}
          </Tabs.List>
          {(Object.entries(guides) as [Device, typeof guides[Device]][]).map(([key, guide]) => <Tabs.Content key={key} value={key} className="install-platform">
            <h3>{guide.title}</h3>
            <ol>{guide.steps.map(step => <li key={step}>{step}</li>)}</ol>
            <p className="install-tip">{guide.tip}</p>
            <a className="install-help" href={guide.help} target="_blank" rel="noreferrer">查看浏览器官方帮助 ↗</a>
          </Tabs.Content>)}
        </Tabs.Root>
        <p className="install-note">在微信或 QQ 里打开的链接，请先选「在浏览器中打开」。首次添加需要你确认一次。游戏已暂停，关闭说明后可继续。</p>
        <Dialog.Close className="install-done">知道了，返回游戏</Dialog.Close>
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}
