"use client";
import { useEffect, useRef } from "react";
import type { Game, GameEvent, Mode } from "@/lib/game";
import { cells, COLORS, NEON_COLORS } from "@/lib/game";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";

// Filled tubes remain legible on a large, light playfield; line-width varies by GPU.
function squareRim(width:number,thickness:number,z=0) {
  const h=width/2,i=h-thickness,shape=new THREE.Shape(),hole=new THREE.Path();
  shape.moveTo(-h,-h);shape.lineTo(h,-h);shape.lineTo(h,h);shape.lineTo(-h,h);shape.closePath();
  hole.moveTo(-i,-i);hole.lineTo(-i,i);hole.lineTo(i,i);hole.lineTo(i,-i);hole.closePath();shape.holes.push(hole);
  return new THREE.ShapeGeometry(shape).translate(0,0,z);
}

export default function Board({game,mode,quietMotion,onReady,onError,effectRef}:{game:Game|null;mode:Mode;quietMotion:boolean;onReady:()=>void;onError:(message:string)=>void;effectRef:React.MutableRefObject<((event:GameEvent)=>void)|null>}) {
  const host=useRef<HTMLDivElement>(null);
  const current=useRef(game);current.current=game;
  const callbacks=useRef({onReady,onError});callbacks.current={onReady,onError};
  useEffect(()=>{
    if(!host.current)return;const parent=host.current;let renderer:THREE.WebGLRenderer;
    try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:"low-power"});}catch{callbacks.current.onError("画面暂时无法启动，请刷新页面或换个浏览器再试。");return;}
    renderer.setPixelRatio(Math.min(window.devicePixelRatio,1.6));renderer.setClearColor(0xf5f4ef,0);renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1;parent.appendChild(renderer.domElement);
    renderer.domElement.setAttribute("aria-hidden","true");
    const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-.12,10.12,20.12,-.12,.1,100);
    camera.position.set(0,0,25);const neon=mode==="neon";const palette=neon?NEON_COLORS:COLORS;
    const motionPreference=window.matchMedia("(prefers-reduced-motion: reduce)");
    const reducedMotion=()=>quietMotion||motionPreference.matches;
    const extras:{dispose:()=>void}[]=[];
    const keep=<T extends {dispose:()=>void}>(item:T):T=>{extras.push(item);return item;};
    const white=new THREE.Color(0xffffff);
    scene.add(new THREE.AmbientLight(0xffffff,neon?.9:1.35));const light=new THREE.DirectionalLight(0xfffdf3,neon?2.7:2.2);light.position.set(-4,20,12);scene.add(light);
    if(neon){const rimLight=new THREE.DirectionalLight(0xa4f5e5,1.8);rimLight.position.set(10,-2,8);scene.add(rimLight);}
    const back=new THREE.Mesh(new THREE.PlaneGeometry(10,20),new THREE.MeshBasicMaterial({color:neon?0xe8efec:0xf8f8f3,toneMapped:false}));back.position.set(5,10,-.5);scene.add(back);
    const verts:number[]=[];for(let x=0;x<=10;x++)verts.push(x,0,-.4,x,20,-.4);for(let y=0;y<=20;y++)verts.push(0,y,-.4,10,y,-.4);
    const gridGeo=new THREE.BufferGeometry();gridGeo.setAttribute("position",new THREE.Float32BufferAttribute(verts,3));
    const grid=new THREE.LineSegments(gridGeo,new THREE.LineBasicMaterial({color:neon?0x95aaa3:0xc2c7b9,transparent:true,opacity:neon?.55:.8}));scene.add(grid);
    const geometry=new RoundedBoxGeometry(.88,.88,neon?.62:.25,2,neon?.09:.035);
    const meshes:THREE.InstancedMesh[]=[];
    const edgeGeo=neon?keep(squareRim(.75,.042,.34)):null,edges:THREE.InstancedMesh[]=[];
    for(let type=1;type<=7;type++){
      const color=new THREE.Color(palette[type]);
      const material=neon?new THREE.MeshPhysicalMaterial({color:color.clone().multiplyScalar(.56),roughness:.18,metalness:.3,clearcoat:1,clearcoatRoughness:.13,emissive:color,emissiveIntensity:.08}):new THREE.MeshStandardMaterial({color,roughness:.76,metalness:.03,emissive:color,emissiveIntensity:.015});
      const mesh=new THREE.InstancedMesh(geometry,material,204);mesh.count=0;mesh.frustumCulled=false;mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);meshes.push(mesh);scene.add(mesh);
      // HDR edge color triggers bloom while the light background stays below its threshold.
      if(edgeGeo){const edge=keep(new THREE.InstancedMesh(edgeGeo,keep(new THREE.MeshBasicMaterial({color:color.clone().lerp(white,.3).multiplyScalar(3.2),toneMapped:false})),204));edge.count=0;edge.frustumCulled=false;edge.instanceMatrix.setUsage(THREE.DynamicDrawUsage);edges.push(edge);scene.add(edge);}
    }
    const sheenGeo=neon?keep(new THREE.BufferGeometry()):null;
    sheenGeo?.setAttribute("position",new THREE.Float32BufferAttribute([-.29,-.06,.35,.24,.28,.35,-.29,.28,.35],3));
    const sheen=sheenGeo?keep(new THREE.InstancedMesh(sheenGeo,keep(new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.2,depthWrite:false})),204)):null;
    if(sheen){sheen.count=0;sheen.frustumCulled=false;scene.add(sheen);}
    const activeMaterial=neon?keep(new THREE.MeshBasicMaterial({transparent:true,opacity:.72,depthWrite:false,toneMapped:false})):null;
    const activeGlow=activeMaterial?keep(new THREE.InstancedMesh(keep(squareRim(.98,.024,.36)),activeMaterial,4)):null;
    if(activeGlow){activeGlow.count=0;activeGlow.frustumCulled=false;scene.add(activeGlow);}
    const ghostGeo=new RoundedBoxGeometry(.85,.85,.04,1,.025),ghostMaterial=new THREE.MeshBasicMaterial({color:neon?0x247b6c:0x59614e,transparent:true,opacity:neon?.09:.13,depthWrite:false});
    const ghost=new THREE.InstancedMesh(ghostGeo,ghostMaterial,4);ghost.count=0;ghost.frustumCulled=false;scene.add(ghost);
    const outlines=new THREE.InstancedMesh(neon?keep(squareRim(.86,.035)):ghostGeo,new THREE.MeshBasicMaterial({color:neon?0x287366:0x59614e,wireframe:!neon,transparent:true,opacity:neon?.72:.48,depthWrite:false}),4);outlines.count=0;outlines.frustumCulled=false;scene.add(outlines);
    const transform=new THREE.Object3D();
    let composer:EffectComposer|null=null;let bloom:UnrealBloomPass|null=null;
    if(neon){composer=new EffectComposer(renderer);composer.addPass(new RenderPass(scene,camera));bloom=new UnrealBloomPass(new THREE.Vector2(440,880),.72,.38,1.15);composer.addPass(bloom);composer.addPass(new OutputPass());}
    const unitPlane=keep(new THREE.PlaneGeometry(1,1));
    const lightMaterial=()=>keep(new THREE.MeshBasicMaterial({transparent:true,depthWrite:false,toneMapped:false}));
    // Bounded pools keep effects cheap even when several pieces land in quick succession.
    const trails=Array.from({length:neon?12:0},()=>{
      const group=new THREE.Group(),material=lightMaterial(),edgeMaterial=lightMaterial();
      const fill=new THREE.Mesh(unitPlane,material);fill.scale.x=.54;group.add(fill);
      for(const x of [-.28,.28]){const edge=new THREE.Mesh(unitPlane,edgeMaterial);edge.position.x=x;edge.scale.x=.026;group.add(edge);}
      group.visible=false;scene.add(group);return {group,material,edgeMaterial,life:0};
    });
    const landingGeo=neon?keep(squareRim(.88,.04)):null;
    const landings=Array.from({length:neon?24:0},()=>{const material=lightMaterial(),mesh=new THREE.Mesh(landingGeo!,material);mesh.visible=false;scene.add(mesh);return {mesh,material,life:0};});
    const waveGeo=neon?keep(new THREE.RingGeometry(.92,1,64)):null;
    const waves=Array.from({length:neon?8:0},()=>{
      const material=lightMaterial(),beamMaterial=lightMaterial(),ring=new THREE.Mesh(waveGeo!,material),beam=new THREE.Mesh(unitPlane,beamMaterial);
      ring.visible=false;beam.visible=false;scene.add(ring,beam);return {ring,beam,material,beamMaterial,life:0};
    });
    const particleCount=neon?320:80;
    const particleData=Array.from({length:particleCount},()=>({x:0,y:0,z:0,vx:0,vy:0,life:0,duration:1,color:new THREE.Color()}));
    const particleGeo=new THREE.BufferGeometry(),positions=new Float32Array(particleCount*3),colors=new Float32Array(particleCount*3),alphas=new Float32Array(particleCount);positions.fill(1000);
    particleGeo.setAttribute("position",new THREE.BufferAttribute(positions,3));particleGeo.setAttribute("particleColor",new THREE.BufferAttribute(colors,3));particleGeo.setAttribute("particleAlpha",new THREE.BufferAttribute(alphas,1));
    const particleMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,toneMapped:false,
      uniforms:{pointSize:{value:(neon?5.5:2.5)*renderer.getPixelRatio()}},
      vertexShader:`attribute vec3 particleColor; attribute float particleAlpha;
        uniform float pointSize; varying vec3 vColor; varying float vAlpha;
        void main(){vColor=particleColor;vAlpha=particleAlpha;gl_PointSize=pointSize;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
      fragmentShader:`varying vec3 vColor; varying float vAlpha;
        void main(){vec2 p=abs(gl_PointCoord-0.5);float diamond=1.0-smoothstep(0.28,0.5,p.x+p.y);
          gl_FragColor=vec4(vColor,vAlpha*diamond);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`});
    const particles=new THREE.Points(particleGeo,particleMat);particles.frustumCulled=false;scene.add(particles);let particleIndex=0;
    let trailIndex=0,landingIndex=0,waveIndex=0;
    const spark=(x:number,y:number,type:number,count:number,speed:number)=>{
      for(let j=0;j<count;j++){const p=particleData[particleIndex++%particleCount];p.x=x;p.y=y;p.z=.8;p.vx=(Math.random()-.5)*speed;p.vy=Math.random()*speed*.7+.7;p.duration=p.life=.55+Math.random()*.55;p.color.set(palette[type]);if(neon)p.color.lerp(white,.24).multiplyScalar(2.5);}
    };
    const landing=(targets:NonNullable<GameEvent["cells"]>)=>{
      for(const c of targets){if(c.y<0||c.y>19)continue;const effect=landings[landingIndex++%landings.length];effect.life=.45;effect.mesh.position.set(c.x+.5,19.5-c.y,.65);effect.material.color.set(palette[c.type]).lerp(white,.25).multiplyScalar(2.6);spark(c.x+.5,19.5-c.y,c.type,3,3);}
    };
    effectRef.current=(e)=>{
      if(reducedMotion())return;
      if(neon&&e.kind==="drop"&&current.current?.state.piece){
        // The event contains the start cells; the game already holds their destination.
        const destination=cells(current.current.state.piece),columns=new Map<number,{top:number;bottom:number;type:number}>();
        (e.cells??[]).forEach((from,i)=>{const to=destination[i];if(!to||to.y<=from.y)return;const column=columns.get(from.x);columns.set(from.x,{top:Math.max(0,Math.min(column?.top??20,from.y)),bottom:Math.min(20,Math.max(column?.bottom??0,to.y+1)),type:from.type});});
        for(const [x,c] of columns){const trail=trails[trailIndex++%trails.length];trail.life=.58;trail.group.position.set(x+.5,20-(c.top+c.bottom)/2,.12);trail.group.scale.y=c.bottom-c.top;trail.material.color.set(palette[c.type]);trail.edgeMaterial.color.set(palette[c.type]).lerp(white,.3).multiplyScalar(2.8);}
      }
      if(neon&&e.kind==="lock")landing(e.cells??[]);
      if(e.kind==="clear"){
        for(const c of e.cells??[])spark(c.x+.5,19.5-c.y,c.type,neon?7:2,neon?8:2);
        if(neon)for(const row of e.rows??[]){const wave=waves[waveIndex++%waves.length];wave.life=.85;wave.ring.position.set(5,19.5-row,.75);wave.beam.position.copy(wave.ring.position);const color=(e.count??1)>=4?0xe9bd67:0x66cfbc;wave.material.color.set(color).lerp(white,.2).multiplyScalar(2.8);wave.beamMaterial.color.set(color);}
      }
    };
    const resize=()=>{const w=parent.clientWidth,h=parent.clientHeight;if(!w||!h)return;renderer.setSize(w,h);composer?.setSize(w,h);};const observer=new ResizeObserver(resize);observer.observe(parent);resize();
    let frame=0,last=0,version=-1,phase=0,lastGame:Game|null=null,visible=!document.hidden;
    const render=(t:number)=>{
      frame=requestAnimationFrame(render);if(!visible||t-last<1000/(neon?45:30))return;const dt=Math.min((t-last)/1000,.06);last=t;
      const g=current.current;
      const animated=g?.state.status==="playing"&&!reducedMotion(),effectDt=animated?dt:0;if(animated)phase+=dt;
      if(g&&(g.version!==version||g!==lastGame)){version=g.version;lastGame=g;const counts=[0,0,0,0,0,0,0];let total=0;
        const put=(x:number,y:number,type:number)=>{if(y<0||y>19)return;transform.position.set(x+.5,19.5-y,0);transform.rotation.set(neon?.035:0,neon?-.045:0,0);transform.scale.set(1,1,1);transform.updateMatrix();const index=counts[type-1]++;meshes[type-1].setMatrixAt(index,transform.matrix);edges[type-1]?.setMatrixAt(index,transform.matrix);sheen?.setMatrixAt(total++,transform.matrix);};
        g.state.board.forEach((r,y)=>r.forEach((type,x)=>{if(type)put(x,y,type);}));if(g.state.piece)cells(g.state.piece).forEach(c=>put(c.x,c.y,c.type));
        meshes.forEach((m,i)=>{m.count=counts[i];m.instanceMatrix.needsUpdate=true;});
        edges.forEach((m,i)=>{m.count=counts[i];m.instanceMatrix.needsUpdate=true;});if(sheen){sheen.count=total;sheen.instanceMatrix.needsUpdate=true;}
        if(activeGlow&&activeMaterial){let n=0;if(g.state.piece&&g.state.status!=="over"){activeMaterial.color.set(palette[g.state.piece.type]).lerp(white,.35).multiplyScalar(2.8);for(const c of cells(g.state.piece)){if(c.y<0||c.y>19)continue;transform.position.set(c.x+.5,19.5-c.y,.02);transform.rotation.set(0,0,0);transform.updateMatrix();activeGlow.setMatrixAt(n++,transform.matrix);}}activeGlow.count=n;activeGlow.instanceMatrix.needsUpdate=true;}
        const target=g.ghost();let n=0;if(target&&target.y!==g.state.piece?.y&&g.state.status!=="over"){for(const c of cells(target)){if(c.y<0)continue;transform.position.set(c.x+.5,19.5-c.y,-.15);transform.rotation.set(0,0,0);transform.updateMatrix();ghost.setMatrixAt(n,transform.matrix);outlines.setMatrixAt(n,transform.matrix);n++;}}
        ghost.count=n;outlines.count=n;ghost.instanceMatrix.needsUpdate=true;outlines.instanceMatrix.needsUpdate=true;
      }
      if(activeMaterial)activeMaterial.opacity=animated?.62+Math.sin(phase*2.4)*.15:.72;
      for(const e of trails){e.life=reducedMotion()?0:Math.max(0,e.life-effectDt);e.group.visible=e.life>0;const fade=Math.pow(e.life/.58,1.5);e.material.opacity=fade*.24;e.edgeMaterial.opacity=fade*.8;}
      for(const e of landings){e.life=reducedMotion()?0:Math.max(0,e.life-effectDt);e.mesh.visible=e.life>0;e.mesh.scale.setScalar(1+(1-e.life/.45)*.45);e.material.opacity=e.life/.45*.8;}
      for(const e of waves){e.life=reducedMotion()?0:Math.max(0,e.life-effectDt);e.ring.visible=e.beam.visible=e.life>0;const p=1-e.life/.85,ease=1-Math.pow(1-p,2);e.ring.scale.set(.5+ease*6,.16+ease*1.8,1);e.beam.scale.set(10,.09+p*.5,1);e.material.opacity=(1-p)*.85;e.beamMaterial.opacity=(1-p)*.22;}
      particleData.forEach((p,i)=>{if(reducedMotion())p.life=0;if(p.life>0){p.life=Math.max(0,p.life-effectDt);p.x+=p.vx*effectDt;p.y+=p.vy*effectDt;p.vy-=5*effectDt;positions[i*3]=p.x;positions[i*3+1]=p.y;positions[i*3+2]=p.z;colors[i*3]=p.color.r;colors[i*3+1]=p.color.g;colors[i*3+2]=p.color.b;alphas[i]=Math.min(1,p.life/p.duration*1.4);}else{positions[i*3]=1000;alphas[i]=0;}});
      particleGeo.attributes.position.needsUpdate=true;particleGeo.attributes.particleColor.needsUpdate=true;particleGeo.attributes.particleAlpha.needsUpdate=true;
      if(composer)composer.render();else renderer.render(scene,camera);
    };
    const visibility=()=>{visible=!document.hidden;last=performance.now();};document.addEventListener("visibilitychange",visibility);
    const lost=(event:Event)=>{event.preventDefault();callbacks.current.onError("画面连接中断，进度已保留，请刷新页面继续。");};renderer.domElement.addEventListener("webglcontextlost",lost);
    frame=requestAnimationFrame(render);callbacks.current.onReady();
    return ()=>{cancelAnimationFrame(frame);observer.disconnect();document.removeEventListener("visibilitychange",visibility);renderer.domElement.removeEventListener("webglcontextlost",lost);effectRef.current=null;geometry.dispose();ghostGeo.dispose();particleGeo.dispose();particleMat.dispose();gridGeo.dispose();(grid.material as THREE.Material).dispose();back.geometry.dispose();(back.material as THREE.Material).dispose();meshes.forEach(m=>{(m.material as THREE.Material).dispose();m.dispose();});ghostMaterial.dispose();(outlines.material as THREE.Material).dispose();ghost.dispose();outlines.dispose();extras.forEach(resource=>resource.dispose());composer?.passes.forEach(p=>p.dispose());composer?.dispose();renderer.dispose();renderer.domElement.remove();};
  },[mode,quietMotion,effectRef]);
  return <div ref={host} className="three-board" role="img" aria-label={`${mode==="classic"?"传统":"霓虹"}俄罗斯方块棋盘，10列20行`} />;
}
